polynomial_str = input("Enter the polynomial (use 'x' as the variable): ")
x_value = int(input("Enter the value of x: "))

terms = polynomial_str.split('+')

result = 0
term_index = 0
num_terms = len(terms)

# Loop through each term of the polynomial
while term_index < num_terms:
    term = terms[term_index]

    # Check if the term has a coefficient and exponent
    if 'x' in term:
        coefficient, exponent = term.split('x')
        # If the coefficient is empty (like in 'x^2'), set it to 1
        if coefficient == '':
            coefficient = '1'
        # If the exponent is empty (like in '3x'), set it to 1
        if exponent == '':
            exponent = '1'
        # Calculate the value of the term and add it to the result
        result += int(coefficient) * (x_value ** int(exponent))
    else:
        # If the term does not contain 'x', it's a constant term
        result += int(term)

    term_index += 1

print(f"The result of evaluating the polynomial at x = {x_value} is: {result}")