n = int(input("Input the total number of students (n>0):"))

index = 0
count = 1

number_list = []
i = 1
while i <= n:
	number_list.append(i)
	i += 1

while len(number_list) > 1:
	if count % 3 == 0:
		number_list.pop(index)
	else:
		index = (index + 1) % len(number_list)
	count += 1
print(number_list[0])