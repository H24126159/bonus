h1 = float(input("Input the height of the 1st ball:"))
m1 = float(input("Input the mass of the 1st ball:"))
m2 = float(input("Input the mass of the 2nd ball:"))
u1 = (2*9.8*h1)**0.5
u2 = 0
v1 = (m1-m2/(m1+m2))*u1
v2 = (2*m1/(m1+m2))*u1
print("The velocity of the 1st ball after slide", u1)
print("The velocity of the 2nd ball after collision", v2)