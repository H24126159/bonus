def evaluate_expression(expression):
    try:
        # 檢查是否有不支援的字元
        for char in expression:
            if not (char.isdigit() or char in "+-*/() "):
                raise ValueError("Unsupported character error: The expression contains unsupported characters.")
        
        # 評估表達式
        result = eval(expression)
        return result

    except ZeroDivisionError:
        return "Division by zero error: Division by zero in the expression."
    except SyntaxError:
        return "Operand error: Missing an operand before or after an operator."
    except ValueError as ve:
        return str(ve)
    except Exception as e:
        return f"錯誤：{str(e)}"

def check_parentheses(expression):
    # not stack 的值為 True，表示括號是平衡的；當堆疊不為空時，not stack 的值為 False，表示括號不是平衡的。

    stack = []  # Create an empty stack
    for char in expression:
        if char == '(':  # If the character is an open parenthesis
            stack.append(char)  # Push it onto the stack
        elif char == ')':  # If the character is a closing parenthesis
            if not stack:  # If the stack is empty
                return False  # Unbalanced parentheses
            stack.pop()  # If the stack[] is not empty, pop the corresponding open parenthesis from the stack
    return not stack  # If the stack is empty, parentheses are balanced; otherwise, unbalanced


def main():

    while True:
        user_input = input("Enter an arithmetic expression: ")
        
        if user_input.lower() == 'q':
            break
        
        # 檢查括號是否平衡
        if not check_parentheses(user_input):
            print("Unbalanced parentheses error: Number of opening and closing parentheses is not equal.")
            continue
        
        # 評估表達式
        result = evaluate_expression(user_input)
        print(result)

if __name__ == "__main__":
    main()