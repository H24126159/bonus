file_name="IMDB-Movie-Data.csv"
file=open(file_name,"r")
text=file.readlines()
# print(text)
file.close()
# print(len(text))

allmovies=[] # 包含所有movies的list
for i in range(1,len(text)):
	movies_info=text[i].split(',')
	allmovies.append(movies_info)
# print(allmovies)
# print(len(allmovies))

def top3movies():
	dict1={}
	for i in range(len(allmovies)):
		dict1[int(allmovies[i][0])] = allmovies[i][1] # [1]=title,[0]=rank
	# print(dict1)

	for key,value in dict1.items():
		sort_rank = sorted(dict1.items())
	top3 = sort_rank[:3]
	# print(top3)
	print("First:",top3[0][1],"\nSecond:",top3[1][1],"\nThird:",top3[2][1])
# top3movies()

def director():
	director=[]
	for i in range(len(allmovies)):
		director.append(allmovies[i][3])
	# print(director)
	count_dict = {}
	for item in director:
	    if item in count_dict:
	        count_dict[item] += 1
	    else:
	        count_dict[item] = 1
	# print(count_dict)
	most_common_str_dict = max(count_dict, key=count_dict.get)
	print(most_common_str_dict)
# director()

def hightest_revenue():
	actors=[]
	every_actor=[]
	dict3={}
	for i in range(len(allmovies)):
		actors.append(allmovies[i][4])
		every_actor.append([actor.strip() for actor in actors[i].split("|")])
		for names in every_actor[i]:
			if names not in dict3:
				dict3[names] = 0.0
			box_office = allmovies[i][9]
			if box_office:
				dict3[names] += float(box_office)
	boxsum_dict = {}
	for item in dict3:
	    if item in boxsum_dict:
	        boxsum_dict[item] += 1
	    else:
	        boxsum_dict[item] = 1
	# print(boxsum_dict)
	hightest_total_revenue = max(boxsum_dict, key=boxsum_dict.get)
	print(hightest_total_revenue)
	# print(actors)
	# print(every_actor)
	# print(dict3)
# hightest_revenue()

def avg_rate():
	actors=[]
	every_actor=[]
	sum_rate=0
	count=0
	for i in range(len(allmovies)):
		actors.append(allmovies[i][4])
		every_actor.append([actor.strip() for actor in actors[i].split("|")])
		for names in every_actor[i]:
			# print(names)
			if names == "Emma Watson":
				# print(names)
				sum_rate += float(allmovies[i][7])
				count+=1
	print(sum_rate/count)
# avg_rate()

def playing_the_most_movies():
	actors=[]
	every_actor=[]
	count=0
	dict5={}
	for i in range(len(allmovies)):
		actors.append(allmovies[i][4])
		every_actor.append([actor.strip() for actor in actors[i].split("|")])
		for names in every_actor[i]:
			if names not in dict5:
				dict5[names] = 0
			dict5[names] += 1
	most_frequent_actor = max(dict5, key=dict5.get)
	# print(every_actor)
	# print(dict5)
	print(most_frequent_actor)
# playing_the_most_movies()

dict6={}
actors=[]
every_actor=[]
sum_rate=0
count=0
for i in range(len(allmovies)):
	actors.append(allmovies[i][4])
	every_actor.append([actor.strip() for actor in actors[i].split("|")])
for i in range(len(allmovies)):
	dict6[allmovies[i][3]]=str(every_actor[i])

print(dict6)










