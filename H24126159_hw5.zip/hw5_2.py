import random

def create_board():
	board=list("_"*30)
	# print(board)
	return board

def visualize_board(board, a_position, b_position):
    result = ''
    for i in range(len(board)):
        if i == a_position:
            result += 'A'
        elif i == b_position:
            result += 'B'
        else:
            result += board[i]
    return result

def unshown_board():
	unshown=list("_"*30)
	un=[]
	for i in range(9):
		penalty_place=random.randint(0,29) #用9次
		if penalty_place not in un:
			# unshown[i]="p"
			un.append(penalty_place)
	for j in un:
		unshown[j]="p"
	return unshown
	# print(unshown)

def roll_a_dice():
	dice = int(random.randint(1,6))
	# print(dice)
	return dice

def play():
    while True:
    	awin,bwin=0,0
    	unshown = unshown_board()
    	board = create_board()

    	a_position, b_position = 0, 0
    	a_points, b_points = 0, 0
    	a_miss_turn, b_miss_turn = False, False

    	while a_position < 30 and b_position < 30:
            if not a_miss_turn:
                a_points = roll_a_dice()
            else:
                a_miss_turn = False

            if not b_miss_turn:
                b_points = roll_a_dice()
            else:
                b_miss_turn = False

            

            a_position += a_points
            if a_position >= 30:
                a_position = 29
                # print("Player A wins!")
                awin=1
                break  # Exit the loop if A wins
            if unshown[a_position] == "p":
                board[a_position] = "a"
                a_miss_turn = True

            b_position += b_points
            if b_position >= 30:
                b_position = 29
                bwin=1
                # print("Player B wins!")
                break  # Exit the loop if B wins
            if unshown[b_position] == "p":
                board[b_position] = "b"
                b_miss_turn = True

            # if a_miss_turn and b_miss_turn:
            #     print("Both players miss turn")

            visual_board = visualize_board(board, a_position, b_position)
            print(visual_board,end="")
            print("(A:", a_points,"B:", b_points,")")
    	visual_board=visualize_board(board,a_position,b_position)
    	print(visual_board)

    	if awin == 0:
        	print("b win")
    	elif bwin == 0:
        	print("a win")
        # print("Game Over")
        # print("Final board:")
        # visual_board = visualize_board(board, a_position, b_position)
        # print(visual_board)
    	break
play()
