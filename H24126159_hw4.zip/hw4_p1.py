# print(" ", end="")
# for k in ["a", "b", "c", "d", "e", "f", "g", "h", "i"]:
#     print("   " + k, end="")
# print()

# print("  "+("+"+"---")*9+"+")
# for i in range(10):
#     for j in range(10):
#            print(j,("|"+"   ")*9+"|")
#            print("  "+("+"+"---")*9+"+")
input

import random

class Minesweeper:
    def __init__(self):
        self.board_size = 9
        self.num_mines = 10
        self.board = [[' ' for _ in range(self.board_size)] for _ in range(self.board_size)]
        self.generate_mines()

    def generate_mines(self):
        mines = random.sample(range(self.board_size * self.board_size), self.num_mines)
        for mine in mines:
            row = mine // self.board_size
            col = mine % self.board_size
            self.board[row][col] = 'X'

    def print_board(self, reveal_all=False):
        print(" ", end="")
        for k in range(self.board_size):
            print(f"   {chr(ord('a') + k)}", end="")
        print("\n  +" + ("---+" * self.board_size))
        for i in range(self.board_size):
            print(f"{i+1} |", end="")
            for j in range(self.board_size):
                if reveal_all or self.board[i][j] != 'X':
                    print(f" {self.board[i][j]} |", end="")
                else:
                    print("   |", end="")
            print(f"\n  +{'---+' * self.board_size}")
        print()

    def is_valid_cell(self, row, col):
        return 0 <= row < self.board_size and 0 <= col < self.board_size

    def count_adjacent_mines(self, row, col):
        count = 0
        for i in range(-1, 2):
            for j in range(-1, 2):
                if i == 0 and j == 0:
                    continue
                if self.is_valid_cell(row + i, col + j) and self.board[row + i][col + j] == 'X':
                    count += 1
        return count

    def uncover_cell(self, row, col):
        if not self.is_valid_cell(row, col):
            print("Invalid cell!")
            return
        if self.board[row][col] == 'X':
            print("Game Over! You hit a mine.")
            self.print_board(reveal_all=True)
            exit()
        elif self.board[row][col] != ' ':
            print("Cell already uncovered!")
            return
        else:
            mines_count = self.count_adjacent_mines(row, col)
            if mines_count == 0:
                self.board[row][col] = '0'
                for i in range(-1, 2):
                    for j in range(-1, 2):
                        if i == 0 and j == 0:
                            continue
                        if self.is_valid_cell(row + i, col + j):
                            self.uncover_cell(row + i, col + j)
            else:
                self.board[row][col] = str(mines_count)

    def toggle_flag(self, row, col):
        if not self.is_valid_cell(row, col):
            print("Invalid cell!")
            return
        if self.board[row][col] == ' ':
            self.board[row][col] = 'F'
        elif self.board[row][col] == 'F':
            self.board[row][col] = ' '

    def play(self):
        self.print_board()
        first_round = True
        while True:
            cell_action = input("Enter cell and action (e.g., a5 uncover/f5 flag/unflag): ")
            if len(cell_action) < 3:
                print("Invalid input! Please enter a valid cell and action.")
                continue
            cell = cell_action[:2]
            action = cell_action[3:]
            if not cell[0].isalpha() or not cell[1].isdigit():
                print("Invalid cell! Please enter a valid cell.")
                continue
            col = ord(cell[0]) - ord('a')
            row = int(cell[1]) - 1
            if first_round and action == 'uncover':
                if self.board[row][col] != ' ':
                    continue
                while True:
                    mines = random.sample(range(self.board_size * self.board_size), self.num_mines + 1)
                    if row * self.board_size + col not in mines:
                        break
                for mine in mines:
                    mine_row = mine // self.board_size
                    mine_col = mine % self.board_size
                    if self.board[mine_row][mine_col] != 'X':
                        self.board[mine_row][mine_col] = 'X'
                        self.num_mines += 1
                first_round = False
            if action == 'uncover':
                self.uncover_cell(row, col)
            elif action == 'flag':
                self.toggle_flag(row, col)
            elif action == 'unflag':
                self.toggle_flag(row, col)
            self.print_board()

game = Minesweeper()
game.play()
