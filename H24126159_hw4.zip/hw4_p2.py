import random

def create_deck():
    ranks = ['ACE', '2', '3', '4', '5', '6', '7', '8', '9', '10', 'JACK', 'QUEEN', 'KING']
    suits = ['SPADE', 'HEART', 'DIAMOND', 'CLUB']
    deck = [{'rank': rank, 'suit': suit} for rank in ranks for suit in suits]
    return deck

def shuffle_deck(deck):
    random.shuffle(deck)
    return deck

def deal_initial_cards(deck):
    player_cards = [deck.pop(), deck.pop()]
    dealer_cards = [deck.pop(), deck.pop()]
    return player_cards, dealer_cards, deck

def compute_total_value(cards):
    total_value = 0
    ace_count = 0
    for card in cards:
        if card['rank'] in ['JACK', 'QUEEN', 'KING']:
            total_value += 10
        elif card['rank'] == 'ACE':
            ace_count += 1
            total_value += 11
        else:
            total_value += int(card['rank'])

    while total_value > 21 and ace_count > 0:
        total_value -= 10
        ace_count -= 1

    return total_value

def player_turn(player_cards, deck):
    while True:
        print("Player's Cards:", player_cards)
        print("Player's Total Value:", compute_total_value(player_cards))
        decision = input("Hit (1) or Stay (0): ")
        if decision == '1':
            new_card = deck.pop()
            player_cards.append(new_card)
            print("New Card for Player:", new_card)
            if compute_total_value(player_cards) > 21:
                return 'bust'
        else:
            return 'stay'

def determine_winner(player_total, dealer_total):
    if player_total == 21:
        return 'player_blackjack'
    elif dealer_total == 21:
        return 'dealer_blackjack'
    elif player_total > 21:
        return 'player_bust'
    elif dealer_total > 21:
        return 'dealer_bust'
    elif player_total > dealer_total:
        return 'player_win'
    elif player_total < dealer_total:
        return 'dealer_win'
    else:
        return 'tie'

def play_blackjack():
    deck = create_deck()
    shuffled_deck = shuffle_deck(deck)

    while True:
        player_cards, dealer_cards, remaining_deck = deal_initial_cards(shuffled_deck)

        player_decision = player_turn(player_cards, remaining_deck)
        if player_decision == 'bust':
            print("Player Busts! Dealer Wins.")
        else:
            dealer_total = compute_total_value(dealer_cards)
            while dealer_total < 17:
                new_card = remaining_deck.pop()
                dealer_cards.append(new_card)
                print("New Card for Dealer:", new_card)
                dealer_total = compute_total_value(dealer_cards)
            print("Dealer's Cards:", dealer_cards)
            print("Dealer's Total Value:", dealer_total)

            result = determine_winner(compute_total_value(player_cards), dealer_total)
            if result == 'player_blackjack':
                print("Player has Blackjack! Player Wins.")
            elif result == 'dealer_blackjack':
                print("Dealer has Blackjack! Dealer Wins.")
            elif result == 'player_win':
                print("Player Wins!")
            elif result == 'dealer_win':
                print("Dealer Wins!")
            else:
                print("It's a Tie!")

        if not play_again():
            print("Thank you for playing!")
            break

def play_again():
    play_again = input("Do you want to play again? (yes/no): ")
    return play_again.lower() == 'yes'

if __name__ == "__main__":
    play_blackjack()
