n = int(input("input an integer number:"))

count = 1

a=0
b=1

while count < n:
    result = a + b
    a=b
    b=result
    count +=1
print("The",n,"-th Fibonacci sequence number is:",result)