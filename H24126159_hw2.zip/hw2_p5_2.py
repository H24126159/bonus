s = input("enter a string:")

n = len(s)
start =0
max_len = 1 #Minimum length of palindrome is 1

#check the odd-length palindromes
if len(s) % 2 == 0:
    for i in range(n):
        left = i
        right = i + 1
        while left >= 0 and right < n and s[left] == s[right]:
            if right - left + 1 > max_len:
                start = left
                max_len = right - left + 1
            left -= 1
            right += 1
    longest_palindrome = s[start : start + max_len]
    print("Length of Longest Palindromic Substring:", max_len)
    print("Longest Palindromic Substring:", longest_palindrome)
    
# Check for odd-length palindromes
elif len(s) % 2 == 1:
    for i in range(n):
        left = i
        right = i
        while left >= 0 and right < n and s[left] == s[right]:
            if right - left + 1 > max_len:
                start = left
                max_len = right - left + 1
            left -= 1
            right += 1
    longest_palindrome = s[start : start + max_len]
    print("Length of Longest Palindromic Substring:", max_len)
    print("Longest Palindromic Substring:", longest_palindrome)