layers = input("Enter the number of layers (2 to 5) = ")
side_length = input("Enter the side length of the top layer = ")
growth = input("Enter the growth of each layer = ")
trunk_width = input("Enter the trunk width (odd number, 3 to 9) = ")
trunk_height = input("Enter the trunk height (4 to 10) = ")

layers = int(layers)
side_length = int(side_length)
growth = int(growth)
final_length_side = side_length + (layers - 1) * growth
bottom_length = final_length_side * 2 - 1
trunk_width = int(trunk_width)
trunk_height = int(trunk_height)

for i in range(0, layers):
    # print(f"side_length: {side_length}")
    for j in range(side_length):
        current_length = 2 * j + 1 #從3開始公差2
        space數 = (bottom_length - current_length) // 2
        if i == 0 and j == 0:
            print(" " * space數 + "#") #聖誕樹最上面的星星
        elif j == 0:
            pass #後面幾層的星星都不用印出
        elif j == side_length - 1:
            print(" " * space數 + "#" + "#" * (2 * j - 1) + "#") #每一個三角形的最後一都是＃
        else:
            print(" " * space數 + "#" + "@" * (2 * j - 1) + "#") #其他
    side_length += growth
count = 0
while count < trunk_height:
	print(((bottom_length-trunk_width)//2)*" "+"|"*trunk_width)
	count += 1