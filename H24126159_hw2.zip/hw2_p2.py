r = k =int(input("input a range:"))
output = ""
for r in range(2,r+1):
	sum_output = 0
	for i in range(1,(r+1)):
		if r%i==0:
			sum_output += i
	if sum_output == r*2:
		print(r)