# Function to calculate nth Fibonacci number
def fibonacci(n):
    fib_sequence = [0, 1]
    while len(fib_sequence) <= n:
        next_num = fib_sequence[-1] + fib_sequence[-2]
        fib_sequence.append(next_num)
    return fib_sequence[n]

# Function to find longest palindromic substring
def longest_palindromic_substring(s):
    n = len(s)
    max_len = 1
    start = 0

    for i in range(n):
        # Check for odd-length palindromes
        left, right = i, i
        while left >= 0 and right < n and s[left] == s[right]:
            if right - left + 1 > max_len:
                start = left
                max_len = right - left + 1
            left -= 1
            right += 1

        # Check for even-length palindromes
        left, right = i, i + 1
        while left >= 0 and right < n and s[left] == s[right]:
            if right - left + 1 > max_len:
                start = left
                max_len = right - left + 1
            left -= 1
            right += 1

    return max_len

# Read input values
n = int(input("Enter the value of n: "))
string1 = input("Enter the first string: ")
string2 = input("Enter the second string: ")
plaintext = input("Enter the plaintext to be encrypted: ")

# Calculate keys for encryption methods
key_caesar = fibonacci(n) % 26
key_affine1 = longest_palindromic_substring(string1)
key_affine2 = longest_palindromic_substring(string2)

# Encryption functions (Caesar Cipher and Affine Cipher)
def caesar_cipher(text, key):
    encrypted_text = ""
    for char in text:
        if char.isalpha():
            shift = ord('A') if char.isupper() else ord('a')
            encrypted_char = chr((ord(char) - shift + key) % 26 + shift)
            encrypted_text += encrypted_char
        else:
            encrypted_text += char
    return encrypted_text

def affine_cipher(text, key1, key2):
    encrypted_text = ""
    for char in text:
        if char.isalpha():
            shift = ord('A') if char.isupper() else ord('a')
            encrypted_char = chr(((ord(char) - shift) * key1 + key2) % 26 + shift)
            encrypted_text += encrypted_char
        else:
            encrypted_text += char
    return encrypted_text

# Encrypt the plaintext using Caesar Cipher and Affine Cipher
encrypted_caesar = caesar_cipher(plaintext, key_caesar)
encrypted_affine = affine_cipher(plaintext, key_affine1, key_affine2)

# Print the encrypted output
print("Caesar Cipher (Key:", key_caesar, "):", encrypted_caesar)
print("Affine Cipher (Keys:", key_affine1, ",", key_affine2, "):", encrypted_affine)
print("Encryption completed.")