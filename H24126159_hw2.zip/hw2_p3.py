year = int(input("enter the year:"))
month = int(input("enter the month:"))

is_leap_year = year % 4 == 0 and (year % 100 != 0 or year % 400 == 0)

days_in_month = 31
if month == 2:
    days_in_month = 29 if is_leap_year(year) else 28
elif month in [4, 6, 9, 11]:
    days_in_month = 30

if month == 2 or month == 1:
    year = year - 1
    month = month + 10
else:
    month = month - 2

a = year//100
b = year%100

kk = b + b//4 + a//4 - 2*a + int(2.6*month-0.2) + 1
day_of_week_first = kk%7 #計算當月的1號是星期幾

calendar_grid = ""
current_day = 1 

for day in range(1,days_in_month+1):
    if day < 10:
        calendar_grid += " "
    if day == 1:
        calendar_grid += "    "*day_of_week_first
    calendar_grid += f"{day}" + "  "
    if day == days_in_month or (day_of_week_first + day) % 7 == 0:
        calendar_grid += "\n" 

print("Sun Mon Tue Wed Thu Fri Sat","\n")
print(calendar_grid)

    # if current_day == 1:
    #     calendar_grid += "    "
    # if current_day == 2:
    #     calendar_grid += "    "*2

    # for week_day_index in range(1,7):
    #     calendar_grid += "    "
    #     continue
    # if week_day_index == 0:
    #     calendar_grid += "  "

# a = ("Sun Mon Tue Wed Thu Fri Sat","\n","01  02  03  04  05  06  07","\n","08  09  10  11  12  13  14","\n","15  16  17  18  19  20  21","\n","22  23  24  25  26  27  28","\n","29  30  31")
# b = ("Sun Mon Tue Wed Thu Fri Sat","\n","    01  02  03  04  05  06","\n","07  08  09  10  11  12  13","\n","14  15  16  17  18  19  20","\n","21  22  23  24  25  26  27","\n","28  29  30  31")
# c = ("Sun Mon Tue Wed Thu Fri Sat","\n","        01  02  03  04  05","\n","06  07  08  09  10  11  12","\n","13  14  15  16  17  18  19","\n","20  21  22  23  24  25  26","\n","27  28  29  30  31")
# d = ("Sun Mon Tue Wed Thu Fri Sat","\n","            01  02  03  04","\n","05  06  07  08  09  10  11","\n","12  13  14  15  16  17  18","\n","19  20  21  22  23  24  25","\n","26  27  28  29  30  31")
# e = ("Sun Mon Tue Wed Thu Fri Sat","\n","                01  02  03","\n","04  05  06  07  08  09  10","\n","11  12  13  14  15  16  17","\n","18  19  20  21  22  23  24","\n","25  26  27  28  29  30  31")
# f = ("Sun Mon Tue Wed Thu Fri Sat","\n","                    01  02","\n","03  04  05  06  07  08  09","\n","10  11  12  13  14  15  16","\n","17  18  19  20  21  22  23","\n","24  25  26  27  28  29  30","\n","31")
# g = ("Sun Mon Tue Wed Thu Fri Sat","\n","                        01","\n","02  03  04  05  06  07  08","\n","09  10  11  12  13  14  15","\n","16  17  18  19  20  21  22","\n","23  24  25  26  27  28  29","\n","30  31")

#看要用哪個（abcdefg）
# if W == 1:
#     print("Sun Mon Tue Wed Thu Fri Sat","\n","    01  02  03  04  05  06","\n","07  08  09  10  11  12  13","\n","14  15  16  17  18  19  20","\n","21  22  23  24  25  26  27","\n","28  29  30  31")
# if W == 2:
#     print("Sun Mon Tue Wed Thu Fri Sat","\n","        01  02  03  04  05","\n","06  07  08  09  10  11  12","\n","13  14  15  16  17  18  19","\n","20  21  22  23  24  25  26","\n","27  28  29  30  31")
# if W == 3:
#     print("Sun Mon Tue Wed Thu Fri Sat","\n","            01  02  03  04","\n","05  06  07  08  09  10  11","\n","12  13  14  15  16  17  18","\n","19  20  21  22  23  24  25","\n","26  27  28  29  30  31")
# if W == 4:
#     print("Sun Mon Tue Wed Thu Fri Sat","\n","                01  02  03","\n","04  05  06  07  08  09  10","\n","11  12  13  14  15  16  17","\n","18  19  20  21  22  23  24","\n","25  26  27  28  29  30  31")
# if W == 5:
#     print("Sun Mon Tue Wed Thu Fri Sat","\n","                    01  02","\n","03  04  05  06  07  08  09","\n","10  11  12  13  14  15  16","\n","17  18  19  20  21  22  23","\n","24  25  26  27  28  29  30","\n","31")
# if W == 6:
#     print("Sun Mon Tue Wed Thu Fri Sat","\n","                        01","\n","02  03  04  05  06  07  08","\n","09  10  11  12  13  14  15","\n","16  17  18  19  20  21  22","\n","23  24  25  26  27  28  29","\n","30  31")
# if W == 0:
#     print("Sun Mon Tue Wed Thu Fri Sat","\n","01  02  03  04  05  06  07","\n","08  09  10  11  12  13  14","\n","15  16  17  18  19  20  21","\n","22  23  24  25  26  27  28","\n","29  30  31")

# if W == 1:
#     print("Monday")
# if W == 2:
#     print("Tuesday")
# if W == 3:
#     print("Wednesday")
# if W == 4:
#     print("Thursday")
# if W == 5:
#     print("Friday")
# if W == 6:
#     print("Saturday")
# if W == 0:
#     print("Sunday")